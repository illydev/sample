### 지원자
   * 이경진 

---



### 선택 과제
   * 인 메모리 캐시 (in-memory cache) 구현

---


### Environment
1. Java version: 17 (JDK 17)
2. Default Encoding: UTF-8

---

### 실행
   * Run `ProductApiApplication`

---

### Test
1. 아래 경로에서 테스트케이스를 확인할 수 있습니다. 
   * com/amore/productapi/infrastructure/cache/CacheServiceTest.java
   * com/amore/productapi/infrastructure/cache/LRUPolicyTest.java
   * com/amore/productapi/service/category/CategoryServiceTest.java
   * com/amore/productapi/service/product/ProductServiceTest.java

2. `ProductApiApplication` 실행 후, 아래 경로의 .http 파일을 통해 API 테스트를 할 수 있습니다.
   * http/category.http
   * http/product.http


---

### DB (h2)
`ProductApiApplication` 실행 후,  http://localhost:8080/h2-console 에 접속합니다. 

`JDBC URL`: jdbc:h2:mem:~/amoretestdb

![h2-console.png](..%2F..%2FDesktop%2Fh2-console.png)

