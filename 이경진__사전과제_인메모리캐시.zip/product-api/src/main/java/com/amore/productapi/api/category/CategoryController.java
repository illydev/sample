package com.amore.productapi.api.category;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.amore.productapi.service.category.CategoryService;
import com.amore.productapi.service.product.ProductService;
import com.amore.productapi.api.category.dto.CategoryResponse;
import com.amore.productapi.api.category.dto.CategoryUpdateRequest;
import com.amore.productapi.api.product.dto.ProductResponse;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class CategoryController {

    private final CategoryService categoryService;

    private final ProductService productService;


    @GetMapping("/api/v1/categories")
    public List<CategoryResponse> getAllCategories() {
        return categoryService.getAllCategories();
    }


    @GetMapping("/api/v1/categories/{categoryNo}")
    public CategoryResponse getCategory(@PathVariable Long categoryNo) {
        return categoryService.getCategory(categoryNo);
    }


    @GetMapping("/api/v1/categories/{categoryNo}/products")
    public List<ProductResponse> getProductsByCategory(@PathVariable Long categoryNo) {
        return productService.getProductsByCategory(categoryNo);
    }


    @PutMapping("/api/v1/categories/{categoryNo}")
    public CategoryResponse updateCategory(@PathVariable Long categoryNo, @RequestBody CategoryUpdateRequest request) {
        return categoryService.updateCategory(categoryNo, request);
    }

}
