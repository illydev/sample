package com.amore.productapi.api.product;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.amore.productapi.service.product.ProductService;
import com.amore.productapi.api.product.dto.ProductAddRequest;
import com.amore.productapi.api.product.dto.ProductResponse;
import com.amore.productapi.api.product.dto.ProductUpdateRequest;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
public class ProductController {

    private final ProductService productService;


    @GetMapping("/api/v1/products/{productNo}")
    public ProductResponse getProduct(@PathVariable Long productNo) {
        return productService.getProduct(productNo);
    }


    @PostMapping("/api/v1/product")
    public ProductResponse addProduct(@RequestBody ProductAddRequest request) {
        return productService.addProduct(request);
    }


    @PutMapping("/api/v1/products/{productNo}")
    public ProductResponse updateProduct(@PathVariable Long productNo, @RequestBody ProductUpdateRequest request) {
        return productService.updateProduct(productNo, request);
    }


    @DeleteMapping("/api/v1/products/{productNo}")
    public ProductResponse deleteProduct(@PathVariable Long productNo) {
        return productService.deleteProduct(productNo);
    }

}
