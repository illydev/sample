package com.amore.productapi.api.product.dto;

import com.amore.productapi.domain.product.Product;

import lombok.Builder;
import lombok.Getter;

@Getter
public class ProductResponse {

    private Long productNo;

    private String productName;

    private Double productPrice;

    private Long categoryNo;

    @Builder
    public ProductResponse(Long productNo, String productName, Double productPrice, Long categoryNo) {
        this.productNo = productNo;
        this.productName = productName;
        this.productPrice = productPrice;
        this.categoryNo = categoryNo;
    }

    public static ProductResponse of(Product product) {
        return ProductResponse.builder()
                              .productNo(product.getProductNo())
                              .productName(product.getProductName())
                              .productPrice(product.getProductPrice())
                              .categoryNo(product.getCategory().getCategoryNo())
                              .build();
    }
}
