package com.amore.productapi.service.category;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.amore.productapi.common.CacheConstants;
import com.amore.productapi.infrastructure.cache.CacheService;
import com.amore.productapi.infrastructure.cache.CachedItem;
import com.amore.productapi.domain.category.Category;
import com.amore.productapi.domain.category.CategoryRepository;
import com.amore.productapi.api.category.dto.CategoryResponse;
import com.amore.productapi.api.category.dto.CategoryUpdateRequest;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CategoryService {

    private final CategoryRepository categoryRepository;

    private final CacheService cacheService;

    /**
     * 전체 카테고리 목록 조회
     * @return 전체 카테고리 목록 반환
     */
    public List<CategoryResponse> getAllCategories() {
        CachedItem cachedItem  = cacheService.get(CacheConstants.CATEGORY_ALL_KEY);
        if (cachedItem != null) {
            return (List<CategoryResponse>) cachedItem.getItem();
        }

        List<CategoryResponse> categoryResponses = categoryRepository.findAll()
                                                                     .stream()
                                                                     .map(CategoryResponse::of)
                                                                     .collect(Collectors.toList());
        cacheService.put(CacheConstants.CATEGORY_ALL_KEY, CachedItem.builder()
                                                                    .item(categoryResponses)
                                                                    .creationTime(LocalDateTime.now())
                                                                    .build());

        return categoryResponses;
    }

    /**
     * 카테고리 정보 조회
     * @param categoryNo
     * @return 카테고리 정보 반환
     */
    public CategoryResponse getCategory(Long categoryNo) {
        CachedItem cachedItem  = cacheService.get(createCategoryCacheKey(categoryNo));
        if (cachedItem != null) {
            return (CategoryResponse) cachedItem.getItem();
        }

        Category category = categoryRepository.findById(categoryNo)
                                              .orElseThrow(() -> new EntityNotFoundException("Category not found: " + categoryNo));

        CategoryResponse categoryResponse = CategoryResponse.of(category);
        cacheService.put(createCategoryCacheKey(categoryNo), CachedItem.builder()
                                                                       .item(categoryResponse)
                                                                       .creationTime(LocalDateTime.now())
                                                                       .build());

        return categoryResponse;
    }

    /**
     * 카테고리 정보 업데이트
     *
     * 카테고리 정보(이름)를 변경하는 경우, 캐시 eviction 처리 합니다.
     * 캐시에 오래된 정보가 남아 있으면 사용자가 최신 정보가 아닌, 오래된 데이터를 보게 됩니다. 데이터 일관성 유지를 위해서 정보가 업데이트 되면 eviction 처리 해야 합니다.
     * @param categoryNo
     * @param request
     * @return
     */
    public CategoryResponse updateCategory(Long categoryNo, CategoryUpdateRequest request) {
        Category category = categoryRepository.findById(categoryNo)
                                              .orElseThrow(() -> new EntityNotFoundException("Category not found"));
        category.setCategoryName(request.getCategoryName());
        categoryRepository.save(category);

        cacheService.evict(createCategoryCacheKey(categoryNo));
        cacheService.evict(CacheConstants.CATEGORY_ALL_KEY);

        return CategoryResponse.of(category);

    }


    private String createCategoryCacheKey(Long categoryNo) {
        return CacheConstants.CATEGORY_KEY_PREFIX + categoryNo;
    }

}
