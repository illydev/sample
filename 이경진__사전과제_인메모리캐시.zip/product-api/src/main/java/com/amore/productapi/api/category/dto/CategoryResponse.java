package com.amore.productapi.api.category.dto;

import com.amore.productapi.domain.category.Category;

import lombok.Builder;
import lombok.Getter;

@Getter
public class CategoryResponse {

    private Long categoryNo;

    private String categoryName;

    private Long parentNo;

    private Long depth;

    @Builder
    public CategoryResponse(Long categoryNo, String categoryName, Long parentNo, Long depth) {
        this.categoryNo = categoryNo;
        this.categoryName = categoryName;
        this.parentNo = parentNo;
        this.depth = depth;
    }

    public static CategoryResponse of(Category category) {
        return CategoryResponse.builder()
                               .categoryNo(category.getCategoryNo())
                               .categoryName(category.getCategoryName())
                               .parentNo(category.getParentNo())
                               .depth(category.getDepth())
                               .build();


    }
}
