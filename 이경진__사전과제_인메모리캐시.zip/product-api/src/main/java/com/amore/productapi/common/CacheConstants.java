package com.amore.productapi.common;

public class CacheConstants {

    public static final String CATEGORY_KEY_PREFIX = "category_";

    public static final String CATEGORY_ALL_KEY = "category_all";

    public static final String PRODUCT_KEY_PREFIX = "product_";

    public static final String CATEGORY_PRODUCTS_KEY_PREFIX = "category_products_";

}
