package com.amore.productapi.api.product.dto;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class ProductUpdateRequest {

    private Long productNo;

    private String productName;

    private Double productPrice;

}
