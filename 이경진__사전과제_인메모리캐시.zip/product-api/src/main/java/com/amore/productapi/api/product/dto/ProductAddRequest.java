package com.amore.productapi.api.product.dto;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class ProductAddRequest {

    private Long productNo;

    private String productName;

    private Double productPrice;

    private String brandName;

    private Long categoryNo;
}
