package com.amore.productapi.api.category.dto;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class CategoryUpdateRequest {

    private Long categoryNo;

    private String categoryName;

}
