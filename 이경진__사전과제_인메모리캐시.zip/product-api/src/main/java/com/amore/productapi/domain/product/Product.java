package com.amore.productapi.domain.product;

import com.amore.productapi.api.product.dto.ProductAddRequest;
import com.amore.productapi.domain.category.Category;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Getter
@Entity
public class Product {
    @Id
    private Long productNo;
    @Setter
    private String productName;
    private String brandName;
    @Setter
    private Double productPrice;

    // Product와 Category n:1 관계
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "categoryNo")
    private Category category;

    @Builder
    public Product(Long productNo, String productName, String brandName, Double productPrice, Category category) {
        this.productNo = productNo;
        this.productName = productName;
        this.brandName = brandName;
        this.productPrice = productPrice;
        this.category = category;
    }

    public static Product of(ProductAddRequest request, Category category) {
        return Product.builder()
                      .productNo(request.getProductNo())
                      .productName(request.getProductName())
                      .brandName(request.getBrandName())
                      .productPrice(request.getProductPrice())
                      .category(category)
                      .build();
    }
}
