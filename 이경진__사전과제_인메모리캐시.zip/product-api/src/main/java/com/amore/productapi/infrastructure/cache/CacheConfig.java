package com.amore.productapi.infrastructure.cache;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CacheConfig {

    @Bean
    public EvictionPolicy evictionPolicy() {
        return new LRUPolicy();
    }

    @Bean
    public CacheService cacheService(EvictionPolicy evictionPolicy) {
        return new CacheService(evictionPolicy);
    }

}
