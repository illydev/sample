package com.amore.productapi.infrastructure.cache;

import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

@Service
public class CacheService {

    private final EvictionPolicy evictionPolicy;

    private final ConcurrentHashMap<String, CachedItem<?>> cache = new ConcurrentHashMap<>();

    private static final int MAX_CAPACITY = 250;


    public CacheService(EvictionPolicy evictionPolicy) {
        this.evictionPolicy = evictionPolicy;
    }

    /**
     * 특정 키로 캐시 아이템 조회
     * @param key
     * @return 캐시 아이템 반환
     */
    public synchronized CachedItem<?> get(String key) {
        CachedItem<?> cachedItem = cache.get(key);
        if (cachedItem == null) {
            return null;
        }

        if (cachedItem.isExpired()) {
            evict(key);
            return null;
        }

        evictionPolicy.access(key);
        return cachedItem;
    }

    /**
     * 캐시 아이템 저장
     * @param key
     * @param item
     */
    public synchronized void put(String key, CachedItem<?> item) {
        if (cache.size() >= MAX_CAPACITY && !cache.containsKey(key)) {
            evictOldest();
        }
        cache.put(key, item);
        evictionPolicy.access(key);
    }

    /**
     * 특정 키의 캐시 아이템 제거
     * @param key
     */
    public synchronized void evict(String key) {
        cache.remove(key);
        evictionPolicy.evict(key);
    }

    /**
     * 가장 오래된 캐시 아이템 항목 제거
     */
    private void evictOldest() {
        String oldestKey = evictionPolicy.oldestItemKey();
        if (oldestKey != null) {
            cache.remove(oldestKey);
            evictionPolicy.evict(oldestKey);
        }
    }

}
