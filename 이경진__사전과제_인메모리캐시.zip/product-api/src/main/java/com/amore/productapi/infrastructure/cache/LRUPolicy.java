package com.amore.productapi.infrastructure.cache;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * LRU (Least Recently Used) 알고리즘이 적합하다고 생각하였습니다.
 *
 * 카테고리와 상품 정보에 대한 조회는 빈번하고, 변경 빈도는 낮은것으로 보입니다.
 * 보통 쇼핑몰에서는 인기있는 카테고리와 상품페이지에 자주 접근되므로 캐시에서 유지되고, 자주 접근되지 않는 항목은 캐시에서 삭제되기 때문에
 * 사용자의 접근 패턴이 변화해도 인기있는 항목이 캐시에 유지되어 효율적입니다.
 */
public class LRUPolicy implements EvictionPolicy {

    private final Set<String> accessOrder = new LinkedHashSet<>(); //요소가 추가된 순서를 유지하므로, 가장 오래된 요소가 Set의 시작 부분에 위치하게 됨.

    /**
     * 캐시 항목에 접근할 때마다 호출됩니다.
     * 주어진 키를 accessOrder에서 제거한 후 다시 추가함으로써 해당 항목을 가장 최근에 접근된 것으로 표시합니다.
     * 해당 항목이 LRU순서에서 맨 끝으로 이동하게 만들어 가장 최근에 사용된 항목이 마지막에 위치하도록 합니다.
     * @param key
     */
    @Override
    public void access(String key) {
        accessOrder.remove(key);
        accessOrder.add(key);
    }

    /**
     * 캐시에서 항목이 제거될 떄 호출됩니다.
     * 주어진 키를 accessOrder에서 제거합니다.
     * @param key
     */
    @Override
    public void evict(String key) {
        accessOrder.remove(key);
    }

    /**
     * 캐시에서 제거할 항목을 결정할 때 호출됩니다.
     * accessOrder의 첫번째 요소 (=가장 오래된 접근)을 반환합니다.
     * 캐시가 최대 용량에 도달했을 때, 제거할 항목을 결정하는데 사용됩니다.
     * @return
     */
    @Override
    public String oldestItemKey() {
        return accessOrder.iterator().hasNext() ? accessOrder.iterator().next() : null;
    }
}
