package com.amore.productapi.infrastructure.cache;

public interface EvictionPolicy {
    void access(String key);
    void evict(String key);
    String oldestItemKey();
}
