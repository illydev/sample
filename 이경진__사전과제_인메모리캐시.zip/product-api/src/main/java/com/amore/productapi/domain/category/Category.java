package com.amore.productapi.domain.category;

import java.util.ArrayList;
import java.util.List;

import com.amore.productapi.domain.product.Product;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Entity
public class Category {

    @Id
    private Long categoryNo;

    @Setter
    private String categoryName;

    private Long parentNo;

    private Long depth;

    @OneToMany(mappedBy = "category")
    private List<Product> products = new ArrayList<>();

    @Builder
    public Category(Long categoryNo, String categoryName, Long parentNo, Long depth) {
        this.categoryNo = categoryNo;
        this.categoryName = categoryName;
        this.parentNo = parentNo;
        this.depth = depth;
    }
}
