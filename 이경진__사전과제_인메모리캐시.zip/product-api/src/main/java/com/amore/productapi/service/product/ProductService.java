package com.amore.productapi.service.product;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.amore.productapi.common.CacheConstants;
import com.amore.productapi.infrastructure.cache.CacheService;
import com.amore.productapi.infrastructure.cache.CachedItem;
import com.amore.productapi.domain.category.Category;
import com.amore.productapi.domain.category.CategoryRepository;
import com.amore.productapi.domain.product.Product;
import com.amore.productapi.api.product.dto.ProductAddRequest;
import com.amore.productapi.domain.product.ProductRepository;
import com.amore.productapi.api.product.dto.ProductResponse;
import com.amore.productapi.api.product.dto.ProductUpdateRequest;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
@Service
public class ProductService {

    private final ProductRepository productRepository;

    private final CategoryRepository categoryRepository;

    private final CacheService cacheService;


    /**
     * 상품 정보 조회
     * @param productNo
     * @return
     */
    public ProductResponse getProduct(Long productNo) {
        CachedItem cachedItem = cacheService.get(createProductCacheKey(productNo));
        if (cachedItem != null) {
            return (ProductResponse) cachedItem.getItem();
        }

        Product product = productRepository.findById(productNo)
                                           .orElseThrow(() -> new EntityNotFoundException("Product not found: " + productNo));

        ProductResponse productResponse = ProductResponse.of(product);
        cacheService.put(createProductCacheKey(productNo), CachedItem.builder()
                                                                     .item(productResponse)
                                                                     .creationTime(LocalDateTime.now())
                                                                     .build());
        return productResponse;
    }


    /**
     * 카테고리별 상품 목록 조회
     * @param categoryNo
     * @return
     */
    public List<ProductResponse> getProductsByCategory(Long categoryNo) {
        String cacheKey = CacheConstants.CATEGORY_PRODUCTS_KEY_PREFIX + categoryNo;
        CachedItem cachedItem = cacheService.get(cacheKey);
        if (cachedItem != null) {
            return (List<ProductResponse>) cachedItem.getItem();
        }

        List<Product> products = productRepository.findByCategoryCategoryNo(categoryNo);
        List<ProductResponse> productResponses = products.stream()
                                                         .map(ProductResponse::of)
                                                         .collect(Collectors.toList());
        cacheService.put(cacheKey, CachedItem.builder()
                                             .item(productResponses)
                                             .creationTime(LocalDateTime.now())
                                             .build());
        return productResponses;
    }


    /**
     * 상품 추가
     *
     * 추가한 카테고리의 '카테고리별 상품목록' 캐시 eviction 처리함. (데이터 일관성을 위해)
     * @param request
     * @return
     */
    public ProductResponse addProduct(ProductAddRequest request) {
        Long categoryNo = request.getCategoryNo();
        Category category = categoryRepository.findById(categoryNo)
                                              .orElseThrow(() -> new EntityNotFoundException("Category not found: " + categoryNo));

        Product product = Product.of(request, category);

        productRepository.save(product);

        cacheService.evict(CacheConstants.CATEGORY_PRODUCTS_KEY_PREFIX + categoryNo);

        return ProductResponse.of(product);
    }



    /**
     * 상품 정보 변경
     *
     * 변경한 상품의 '상품 정보' 캐시 eviction 처리함. (데이터 일관성을 위해)
     * @param productNo
     * @param request
     * @return
     */
    public ProductResponse updateProduct(Long productNo, ProductUpdateRequest request) {
        Product product = productRepository.findById(productNo)
                                           .orElseThrow(() -> new EntityNotFoundException("Product not found: " + productNo));
        product.setProductName(request.getProductName());
        product.setProductPrice(request.getProductPrice());
        productRepository.save(product);

        cacheService.evict(createProductCacheKey(productNo));

        return ProductResponse.of(product);
    }


    /**
     * 상품 삭제
     *
     * 삭제한 상품의 '상품 정보' 캐시 eviction 처리함. (데이터 일관성을 위해)
     * 삭제한 상품의 카테고리에 대한 '카테고리별 상품목록' 캐시도 eviction 처리함.
     * @param productNo
     * @return
     */
    public ProductResponse deleteProduct(Long productNo) {
        Product product = productRepository.findById(productNo)
                                           .orElseThrow(() -> new EntityNotFoundException("Product not found: " + productNo));
        productRepository.delete(product);

        cacheService.evict(createProductCacheKey(productNo));
        cacheService.evict(CacheConstants.CATEGORY_PRODUCTS_KEY_PREFIX + product.getCategory().getCategoryNo());

        return ProductResponse.of(product);
    }


    private String createProductCacheKey(Long productNo) {
        return CacheConstants.PRODUCT_KEY_PREFIX + productNo;
    }

}
