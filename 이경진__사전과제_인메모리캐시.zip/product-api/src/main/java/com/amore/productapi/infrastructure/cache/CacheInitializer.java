package com.amore.productapi.infrastructure.cache;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.amore.productapi.domain.category.CategoryRepository;
import com.amore.productapi.service.category.CategoryService;
import com.amore.productapi.service.product.ProductService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class CacheInitializer implements CommandLineRunner {

    private final CategoryService categoryService;

    private final CategoryRepository categoryRepository;

    private final ProductService productService;

    @Override
    public void run(String... args) {
        categoryService.getAllCategories();

        categoryRepository.findAll()
                          .forEach(category -> {
                              productService.getProductsByCategory(category.getCategoryNo());
                          });
    }


}
