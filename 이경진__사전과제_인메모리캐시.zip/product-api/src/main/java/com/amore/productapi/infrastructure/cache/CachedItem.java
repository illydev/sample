package com.amore.productapi.infrastructure.cache;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Getter;

@Getter
public class CachedItem<T> {

    private final T item;

    private final LocalDateTime creationTime;
    private final LocalDateTime expirationTime;
    private static final long DEFAULT_DURATION_SECONDS = 60 * 60 * 24;


    @Builder
    public CachedItem(T item, LocalDateTime creationTime, Long durationSeconds) {
        this.item = item;
        this.creationTime = creationTime;
        this.expirationTime = this.creationTime.plusSeconds(durationSeconds != null ? durationSeconds : DEFAULT_DURATION_SECONDS);
    }

    public boolean isExpired() {
        return LocalDateTime.now().isAfter(expirationTime);
    }
}
