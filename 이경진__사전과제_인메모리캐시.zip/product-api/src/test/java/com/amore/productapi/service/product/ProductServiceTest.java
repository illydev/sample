package com.amore.productapi.service.product;

import java.time.LocalDateTime;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.amore.productapi.common.CacheConstants;
import com.amore.productapi.domain.category.Category;
import com.amore.productapi.domain.category.CategoryRepository;
import com.amore.productapi.domain.product.Product;
import com.amore.productapi.domain.product.ProductRepository;
import com.amore.productapi.infrastructure.cache.CacheService;
import com.amore.productapi.infrastructure.cache.CachedItem;
import com.amore.productapi.service.product.ProductService;
import com.amore.productapi.api.product.dto.ProductAddRequest;
import com.amore.productapi.api.product.dto.ProductResponse;
import com.amore.productapi.api.product.dto.ProductUpdateRequest;

import jakarta.persistence.EntityNotFoundException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest
class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    @Mock
    private CategoryRepository categoryRepository;

    @Mock
    private CacheService cacheService;

    @InjectMocks
    private ProductService productService;

    @DisplayName("상품번호로 상품 정보를 조회할 때, 캐시에 데이터가 있는 경우 캐시 데이터를 반환한다. 디비는 조회하지 않는다.")
    @Test
    void getProduct_WhenFoundInCache() {
        // given
        Long productNo = 1L;
        Category category = Category.builder().categoryNo(1L).categoryName("스킨케어").depth(1L).build();
        Product product = Product.builder()
                                 .productNo(productNo)
                                 .productName("스킨케어 테스트 상품1")
                                 .productPrice(10000.00)
                                 .category(category)
                                 .build();
        CachedItem cachedItem = CachedItem.builder().item(ProductResponse.of(product)).creationTime(LocalDateTime.now()).build();

        when(cacheService.get(anyString())).thenReturn(cachedItem);


        // when
        ProductResponse result = productService.getProduct(productNo);


        // then
        assertEquals(ProductResponse.of(product).getProductNo(), result.getProductNo());
        assertEquals(ProductResponse.of(product).getProductName(), result.getProductName());
        assertEquals(ProductResponse.of(product).getCategoryNo(), result.getCategoryNo());
        verify(productRepository, never()).findById(anyLong());
    }


    @DisplayName("상품번호로 상품 정보를 조회할 때, 캐시에 데이터가 없는 경우 디비를 조회하여 반환한다. 디비 조회한 데이터는 캐시에 put 한다.")
    @Test
    void getProduct_WhenNotFoundInCache() {
        // given
        Long productNo = 1L;
        Category category = Category.builder().categoryNo(1L).categoryName("스킨케어").depth(1L).build();
        Product product = Product.builder()
                                 .productNo(productNo)
                                 .productName("스킨케어 테스트 상품1")
                                 .productPrice(10000.00)
                                 .category(category)
                                 .build();

        when(cacheService.get(anyString())).thenReturn(null);
        when(productRepository.findById(productNo)).thenReturn(Optional.of(product));

        // when
        ProductResponse result = productService.getProduct(productNo);


        // then
        assertEquals(ProductResponse.of(product).getProductNo(), result.getProductNo());
        assertEquals(ProductResponse.of(product).getProductName(), result.getProductName());
        assertEquals(ProductResponse.of(product).getCategoryNo(), result.getCategoryNo());
        verify(productRepository).findById(productNo);
        verify(cacheService).put(anyString(), any(CachedItem.class));
    }


    @DisplayName("새로운 상품을 추가한다. 추가된 상품의 카테고리에 대한 카테고리별 상품 목록 캐시를 eviction 처리한다.")
    @Test
    void addProduct_Success() {
        // given
        Long categoryNo = 1L;
        Category category = Category.builder().categoryNo(1L).categoryName("스킨케어").depth(1L).build();
        ProductAddRequest request = ProductAddRequest.builder()
                                                     .productNo(1002L)
                                                     .productName("테스트상품추가")
                                                     .productPrice(10000.00)
                                                     .brandName("테스트브랜드")
                                                     .categoryNo(categoryNo)
                                                     .build();

        when(categoryRepository.findById(categoryNo)).thenReturn(Optional.of(category));

        Product product = Product.of(request, category);
        when(productRepository.save(any(Product.class))).thenReturn(product);


        // when
        ProductResponse result = productService.addProduct(request);


        // then
        assertEquals(ProductResponse.of(product).getProductNo(), result.getProductNo());
        assertEquals(ProductResponse.of(product).getProductName(), result.getProductName());
        assertEquals(ProductResponse.of(product).getCategoryNo(), result.getCategoryNo());
        verify(categoryRepository).findById(categoryNo);
        verify(productRepository).save(any(Product.class));
        verify(cacheService).evict(CacheConstants.CATEGORY_PRODUCTS_KEY_PREFIX + categoryNo);
    }


    @DisplayName("새로운 상품을 추가할 때, 카테고리를 찾을 수 없을 경우 예외 발생 확인")
    @Test
    void addProduct_CategoryNotFound_ThrowsException() {
        Long categoryNo = 1L;
        Category category = Category.builder().categoryNo(1L).categoryName("스킨케어").depth(1L).build();
        ProductAddRequest request = ProductAddRequest.builder()
                                                     .productNo(1002L)
                                                     .productName("테스트상품추가")
                                                     .productPrice(10000.00)
                                                     .brandName("테스트브랜드")
                                                     .categoryNo(categoryNo)
                                                     .build();
        when(categoryRepository.findById(categoryNo)).thenReturn(Optional.empty());

        EntityNotFoundException thrownException = assertThrows(EntityNotFoundException.class, () -> {
            productService.addProduct(request);
        });

        assertEquals("Category not found: " + categoryNo, thrownException.getMessage());
        verify(categoryRepository).findById(categoryNo);
        verify(productRepository, never()).save(any(Product.class));
    }


    @DisplayName("특정 상품번호를 가진 상품의 상품명과 가격을 업데이트한다. 업데이트된 상품번호에 대한 캐시를 eviction 처리한다.")
    @Test
    void updateProduct_Success() {
        // given
        Long productNo = 1L;
        ProductUpdateRequest request = ProductUpdateRequest.builder()
                                                           .productNo(productNo)
                                                           .productName("업데이트된 상품명")
                                                           .productPrice( 20000.00)
                                                           .build();
        Category category = Category.builder().categoryNo(1L).categoryName("스킨케어").depth(1L).build();
        Product product = Product.builder()
                                 .productNo(productNo)
                                 .productName("상품명")
                                 .productPrice(10000.00)
                                 .category(category)
                                 .build();

        when(productRepository.findById(productNo)).thenReturn(Optional.of(product));


        // when
        ProductResponse result = productService.updateProduct(productNo, request);


        // then
        assertEquals(request.getProductName(), product.getProductName());
        assertEquals(request.getProductPrice(), product.getProductPrice());
        verify(productRepository).save(product);
        verify(cacheService).evict(CacheConstants.PRODUCT_KEY_PREFIX + productNo);
    }


    @DisplayName("특정 상품번호를 가진 상품을 삭제한다. 삭제된 상품번호에 대한 캐시 및 카테고리별 상품 목록 캐시를 eviction 처리한다.")
    @Test
    void deleteProduct_Success() {
        // given
        Long productNo = 1L;
        Long categoryNo = 1L;
        Category category = Category.builder().categoryNo(categoryNo).categoryName("스킨케어").depth(1L).build();
        Product product = Product.builder()
                                 .productNo(productNo)
                                 .productName("상품명")
                                 .productPrice(10000.00)
                                 .category(category)
                                 .build();

        when(productRepository.findById(productNo)).thenReturn(Optional.of(product));

        // when
        ProductResponse result = productService.deleteProduct(productNo);

        // then
        verify(productRepository).delete(product);
        verify(cacheService).evict(CacheConstants.PRODUCT_KEY_PREFIX + productNo);
        verify(cacheService).evict(CacheConstants.CATEGORY_PRODUCTS_KEY_PREFIX + categoryNo);
    }

}