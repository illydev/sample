package com.amore.productapi.service.category;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.amore.productapi.common.CacheConstants;
import com.amore.productapi.domain.category.Category;
import com.amore.productapi.domain.category.CategoryRepository;
import com.amore.productapi.infrastructure.cache.CacheService;
import com.amore.productapi.infrastructure.cache.CachedItem;
import com.amore.productapi.service.category.CategoryService;
import com.amore.productapi.api.category.dto.CategoryResponse;
import com.amore.productapi.api.category.dto.CategoryUpdateRequest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest
class CategoryServiceTest {

    @Mock
    private CategoryRepository categoryRepository;

    @Mock
    private CacheService cacheService;

    @InjectMocks
    private CategoryService categoryService;


    @DisplayName("전체 카테고리 목록 조회시 캐시에 데이터가 있는 경우, 디비 조회는 하지 않는다.")
    @Test
    void getAllCategories_WhenFoundInCache() {
        // given
        LocalDateTime createdDateTime = LocalDateTime.now();
        List<Category> categories = List.of(
            createCategory(1, "스킨케어", 1),
            createCategory(2, "메이크업", 1),
            createCategory(3, "생활용품", 1)
        );
        List<CategoryResponse> cachedCategories = categories.stream()
                                                            .map(CategoryResponse::of)
                                                            .collect(Collectors.toList());
        CachedItem cachedItem = CachedItem.builder()
                                          .item(cachedCategories)
                                          .creationTime(createdDateTime).build();

        when(cacheService.get(CacheConstants.CATEGORY_ALL_KEY)).thenReturn(cachedItem);


        // when
        List<CategoryResponse> result = categoryService.getAllCategories();


        // then
        assertEquals(cachedCategories, result);
        verify(categoryRepository, never()).findAll();
    }


    @DisplayName("전체 카테고리 목록 조회시 캐시에 데이터가 없는 경우, 디비를 조회하여 데이터를 가져온다. 디비에서 조회한 데이터는 다시 캐시에 저장한다.")
    @Test
    void getCategory_WhenNotFoundInCache() {
        // given
        Long categoryNo = 1L;
        Category category = createCategory(categoryNo, "스킨케어", 1);
        when(categoryRepository.findById(categoryNo)).thenReturn(Optional.of(category));
        when(cacheService.get("category_" + categoryNo)).thenReturn(null);
        CategoryResponse expectedResponse = CategoryResponse.of(category);

        // when
        CategoryResponse actualResponse = categoryService.getCategory(categoryNo);

        // then
        assertEquals(expectedResponse.getCategoryNo(), actualResponse.getCategoryNo());
        assertEquals(expectedResponse.getCategoryName(), actualResponse.getCategoryName());
        verify(categoryRepository).findById(categoryNo);
        verify(cacheService).put(anyString(), any(CachedItem.class));
    }

    @DisplayName("카테고리 정보가 업데이트 될 때, 해당 카테고리 번호로 생성된 캐시는 eviction 된다. 전체 카테고리 목록에 대한 캐시도 eviction 된다.")
    @Test
    void updateCategory_Success() {
        // given
        Long categoryNo = 1L;
        String updateCategoryName = "스킨케어 NEW";
        CategoryUpdateRequest request = CategoryUpdateRequest.builder()
                                                             .categoryNo(categoryNo)
                                                             .categoryName(updateCategoryName)
                                                             .build();
        Category category = createCategory(categoryNo, "스킨케어", 1);

        when(categoryRepository.findById(categoryNo)).thenReturn(Optional.of(category));


        // when
        CategoryResponse result = categoryService.updateCategory(categoryNo, request);


        // then
        assertEquals(request.getCategoryName(), category.getCategoryName());
        verify(categoryRepository).save(category);
        verify(cacheService).evict("category_" + categoryNo);
        verify(cacheService).evict(CacheConstants.CATEGORY_ALL_KEY);
    }

    private Category createCategory(long categoryNo, String categoryName, long depth) {
        return Category.builder().categoryNo(categoryNo).categoryName(categoryName).depth(depth).build();
    }

}