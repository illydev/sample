package com.amore.productapi.infrastructure.cache;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class CacheServiceTest {

    private CacheService cacheService;
    private EvictionPolicy evictionPolicy;

    @BeforeEach
    void setUp() {
        evictionPolicy = mock(EvictionPolicy.class);
        cacheService = new CacheService(evictionPolicy);
    }

    @Test
    void testPutAndGet() {
        String key = "testKey";
        CachedItem cachedItem = CachedItem.builder()
                                          .item("testValue")
                                          .creationTime(LocalDateTime.now())
                                          .build();

        cacheService.put(key, cachedItem);
        verify(evictionPolicy).access(key);

        CachedItem retrievedItem = cacheService.get(key);
        assertEquals(cachedItem, retrievedItem);
    }

    @Test
    void testEvict() {
        String key = "testKey";
        CachedItem cachedItem = CachedItem.builder()
                                          .item("testValue")
                                          .creationTime(LocalDateTime.now())
                                          .build();

        cacheService.put(key, cachedItem);
        cacheService.evict(key);

        assertNull(cacheService.get(key));
        verify(evictionPolicy).evict(key);
    }

}