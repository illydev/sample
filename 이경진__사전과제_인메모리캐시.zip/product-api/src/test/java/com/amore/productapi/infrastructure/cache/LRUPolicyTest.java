package com.amore.productapi.infrastructure.cache;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LRUPolicyTest {

    private LRUPolicy lruPolicy;

    @BeforeEach
    void setUp() {
        lruPolicy = new LRUPolicy();
    }


    @Test
    void testAccessOrder() {
        lruPolicy.access("item1");
        lruPolicy.access("item2");
        lruPolicy.access("item3");

        lruPolicy.access("item2");

        assertEquals("item1", lruPolicy.oldestItemKey());
    }


    @Test
    void testEvict() {
        lruPolicy.access("item1");
        lruPolicy.access("item2");
        lruPolicy.access("item3");

        lruPolicy.evict("item2");

        assertEquals("item1", lruPolicy.oldestItemKey());
    }


    @Test
    void testEvictOldest() {
        lruPolicy.access("item1");
        lruPolicy.access("item2");
        lruPolicy.access("item3");

        String evictedItem = lruPolicy.oldestItemKey();
        lruPolicy.evict(evictedItem);

        assertEquals("item2", lruPolicy.oldestItemKey());
    }
}